from django.contrib import admin
from .models import Problem, Solution

@admin.register(Problem)
class ProblemAdmin(admin.ModelAdmin):
    list_display = ('created_by', 'title')  # Display these fields in the admin list view
    search_fields = ('title',)  # Add a search bar for the title


@admin.register(Solution)
class SolutionAdmin(admin.ModelAdmin):
    list_display = ('id', 'problem', 'student')
    list_filter = ('problem',)  # Add a filter for related problems